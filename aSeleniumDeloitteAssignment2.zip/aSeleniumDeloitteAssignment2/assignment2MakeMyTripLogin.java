package aSeleniumDeloitteAssignment2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class assignment2MakeMyTripLogin {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\software testing\\selenium\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.makemytrip.com");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector("#SW > div.landingContainer > div.makeFlex.hrtlCenter.prependTop5.appendBottom40 > ul > li.makeFlex.hrtlCenter.font10.makeRelative.lhUser")).click();
		driver.findElement(By.id("username")).sendKeys("7904969347");
		driver.findElement(By.cssSelector(".modalLogin")).click();
		driver.findElement(By.cssSelector("button")).click();
				

	}

}
